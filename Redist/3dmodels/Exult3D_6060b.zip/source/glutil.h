/*
 *      glutil.h - Classes that help us operate in 3D
 *
 *      Written: 2004-10-08 Sam Matthews
 *
 *  Copyright (C) 2002  The Exult Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef GLUTIL_H
#define GLUTIL_H       1

#ifdef HAVE_OPENGL

#ifndef sqr
#define sqr(a) ((a)*(a))
#endif

#include <GL/gl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

class Vector3
{	
public:
	union
	{
		GLfloat x, u, r;
	};
	union
	{
		GLfloat y, v, g;
	};
	union
	{
		GLfloat z, w, b;
	};
	//GLfloat x,y,z;
	Vector3()
	{
	}
	Vector3( GLfloat x, GLfloat y, GLfloat z )
	{
		this->x = x;
		this->y = y;
		this->z = z;
	}
	GLfloat &operator[]( int i )
	{
		switch( i )
		{
		case 0:
			return x;
		case 1:
			return y;
		default:
			return z;
		}
	}
	bool operator<( Vector3 that ) const
	{
		if( this->x < that.x &&
			this->y < that.y &&
			this->z < that.z )
			return true;
		return false;
	}
	bool operator>( Vector3 that ) const
	{
		if( this->x > that.x &&
			this->y > that.y &&
			this->z > that.z )
			return true;
		return false;
	}
	bool operator==( Vector3 that ) const
	{
		if( ( this->x == that.x ) && ( this->y == that.y ) && ( this->y == that.y ) )
			return true;
		else
			return false;
	}
	bool operator!=( Vector3 that ) const
	{
		if( ( this->x == that.x ) && ( this->y == that.y ) && ( this->y == that.y ) )
			return false;
		else
			return true;
	}
	Vector3 operator*( const GLfloat scale ) const
	{
		Vector3 Vector( x, y, z );
		Vector.x *= scale;
		Vector.y *= scale;
		Vector.z *= scale;
		return Vector;
	}
	Vector3 operator/( const GLfloat scale ) const
	{
		Vector3 Vector( x, y, z );
		Vector.x /= scale;
		Vector.y /= scale;
		Vector.z /= scale;
		return Vector;
	}
	Vector3 operator+( const GLfloat amount ) const
	{
		Vector3 Vector( x, y, z );
		Vector.x += amount;
		Vector.y += amount;
		Vector.z += amount;
		return Vector;
	}
	Vector3 operator-( const GLfloat amount ) const
	{
		Vector3 Vector( x, y, z );
		Vector.x -= amount;
		Vector.y -= amount;
		Vector.z -= amount;
		return Vector;
	}
	Vector3 operator*( const Vector3 that ) const
	{
		Vector3 Vector( x, y, z );
		Vector.x *= that.x;
		Vector.y *= that.y;
		Vector.z *= that.z;
		return Vector;
	}
	Vector3 operator+( const Vector3 that ) const
	{
		Vector3 Vector( x, y, z );
		Vector.x += that.x;
		Vector.y += that.y;
		Vector.z += that.z;
		return Vector;
	}
	Vector3 operator-( const Vector3 that ) const
	{
		Vector3 Vector( x, y, z );
		Vector.x -= that.x;
		Vector.y -= that.y;
		Vector.z -= that.z;
		return Vector;
	}
	Vector3 &operator*=( const Vector3 that )
	{
		this->x *= that.x;
		this->y *= that.y;
		this->z *= that.z;
		return *this;
	}
	Vector3 &operator/=( const Vector3 that )
	{
		this->x /= that.x;
		this->y /= that.y;
		this->z /= that.z;
		return *this;
	}
	Vector3 &operator+=( const Vector3 that )
	{
		this->x += that.x;
		this->y += that.y;
		this->z += that.z;
		return *this;
	}
	Vector3 &operator-=( const Vector3 that )
	{
		this->x -= that.x;
		this->y -= that.y;
		this->z -= that.z;
		return *this;
	}
	Vector3 operator*=( const GLfloat scale )
	{
		this->x *= scale;
		this->y *= scale;
		this->z *= scale;
		return *this;
	}
	Vector3 operator/=( const GLfloat scale )
	{
		this->x /= scale;
		this->y /= scale;
		this->z /= scale;
		return *this;
	}
	Vector3 &operator=( GLfloat that )
	{
		this->x = this->y = this->z = that;
		return *this;
	}
	Vector3 &operator=( GLint that )
	{
		this->x = this->y = this->z = GLfloat(that);
		return *this;
	}
	Vector3 operator-( void )
	{
		return *this * -1;
	}
	GLfloat get_mag( void )
	{
		return GLfloat(sqrt(sqr(x) + sqr(y) + sqr(z)));
	}
	Vector3 get_unit( void )
	{
		GLfloat Len = get_mag();
		if( Len < 0.001f )
			Len = 0.001f;
		return *this / Len;
	}
	void set_unit( void )
	{
		*this = this->get_unit();
	}
	void set_clamp( float ceil = 360.0f )
	{
		while( x > ceil )	x -= ceil;
		while( x < 0 )		x += ceil;
		while( y > ceil )	y -= ceil;
		while( y < 0 )		y += ceil;
		while( z > ceil )	z -= ceil;
		while( z < 0 )		z += ceil;
	}
	bool is_empty( void )
	{
		return( x == 0.0 && y == 0.0 && z == 0.0 );
	}
	GLfloat get_dot( const Vector3 &that )
	{
		return x*that.x+y*that.y+z*that.z;
	}
	static GLfloat get_dot( const Vector3 &v0, const Vector3 &v1 )
	{
		return v0.x*v1.x+v0.y*v1.y+v0.z*v1.z;
	}
	Vector3 get_cross( const Vector3 &v1 )
	{
		Vector3 v0 = *this;
		return Vector3( ( v0.y * v1.z ) - ( v0.z * v1.y ),
				( v0.z * v1.x ) - ( v0.x * v1.z ),
				( v0.x * v1.y ) - ( v0.y * v1.x ) );
	}
	static Vector3 get_cross( const Vector3 &v0, const Vector3 &v1, const Vector3 &v2, const Vector3 &v3 )
	{
		return Vector3( (v1.z - v3.z) * (v2.y - v0.y) - (v1.y - v3.y) * (v2.z - v0.z),
				(v1.x - v3.x) * (v2.z - v0.z) - (v1.z - v3.z) * (v2.x - v0.x),
				(v1.y - v3.y) * (v2.x - v0.x) - (v1.x - v3.x) * (v2.y - v0.y) );
	}
	static Vector3 get_reflection( Vector3 i, Vector3 n )
	{
		//i = incident vector, n = normal vector, r = reflected vector
		//r = n*2*DotProduct(-i, n)+i
		return n*2*get_dot( -i, n )+i;
	}	
};


#endif //HAVE_OPENGL
#endif //GLUTIL_H
