/*
 *	glshape.cc - Paint 2D shapes in OpenGL
 *
 *	Written: 7/16/02 - JSF
 *
 *  Copyright (C) 2002  The Exult Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#ifdef HAVE_OPENGL

#include <GL/glu.h>
#include <GL/gl.h>
#include <GL/glext.h>

#include "gamewin.h"
#include "actors.h"

#include "objs/animate.h"
#include "objs/objs.h"
#include "objs/chunks.h"
#include "glshape.h"
#include "glutil.h"
#include "vgafile.h"
#include "utils.h"
#include "exult_constants.h"
#include "ibuf8.h"
#include "objiter.h"
#include "model3d.h"

GL_manager *GL_manager::instance = 0;

const unsigned char transp = 255;	// Transparent pixel.

/*
 *	Create from a given source.  Assumes src is square, with texsize
 *	already set to length.
 */

void GL_texshape::create
	(
	Image_buffer8 *src,		// Source image.
	unsigned char *pal,		// 3*256 bytes (rgb).
	Xform_palette *xforms,		// Transforms translucent colors if !0.
	int xfcnt			// Number of xforms.
	)
	{
	assert(pal != 0);
	unsigned char *pixels = src->rgba(pal, transp, 0xF4, 0xFE, xforms );
	glGenTextures(1, &texture);	// Generate (empty) texture.
	glBindTexture(GL_TEXTURE_2D, texture);
					// +++++Might want GL_RGBA, depending
					//   on video card.
					// Need translucency?
	GLint iformat = GL_RGBA4;
	iformat = GL_RGBA;
	glTexImage2D(GL_TEXTURE_2D, 0, iformat, texsize, texsize, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
	delete pixels;
					// Linear filtering.
#if 1
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
#else	/* This looks less blurry, and helps get rid of the lines.	*/
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
#endif
	// Enable texture clamping. This will get rid of all the lines everywhere
	// -Colourless
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	}

/*
 *	Create for a given frame.
 */

GL_texshape::GL_texshape
	(
	Shape_frame *f,
	unsigned char *pal,		// 3*256 bytes (rgb).
	Xform_palette *xforms,		// Transforms translucent colors if !0.
	int xfcnt			// Number of xforms.
	) : frame(f), lru_next(0), lru_prev(0)
	{
	int w = frame->get_width(), h = frame->get_height();
					// Figure texture size as 2^n, rounding
					//   up.
	int logw = Log2(2*w - 1), logh = Log2(2*h - 1);
	texsize = 1<<(logw > logh ? logw : logh);
					// Render frame.
	Image_buffer8 buf8(texsize, texsize);
	buf8.fill8(transp);		// Fill with transparent value.
//	buf8.fill8(40);			// Fill with random value

#if 0
	buf8.fill8( 50, texsize, texsize, texsize-frame->get_width(), texsize-frame->get_height() ); //Fill the area that SHOULD be painted onto
	frame->paint( &buf8, texsize - frame->get_xright() - 1, texsize - frame->get_ybelow() - 1 );
#else
//	buf8.fill8( 50, frame->get_width(), frame->get_height(), 0, 0 ); //Fill the area that SHOULD be painted onto
	frame->paint( &buf8, frame->get_width() - frame->get_xright() - 1, frame->get_height() - frame->get_ybelow() - 1 );
#endif

	create(&buf8, pal, xforms, xfcnt);
//puts("Creating a GL_texshape from a frame");
	}

/*
 *	Create from a given (square, size 2^n) image.
 */

GL_texshape::GL_texshape
	(
	Image_buffer8 *src,		// Must be square.
	unsigned char *pal		// 3*256 bytes (rgb).
	) : frame(0), lru_next(0), lru_prev(0)
	{
	int w = src->get_width(), h = src->get_height();
	assert (w == h);
	assert ((1<<Log2(w)) == w);
	texsize = w;
	create(src, pal);
	}

/*
 *	Free resources.
 */

GL_texshape::~GL_texshape
	(
	)
	{
	glDeleteTextures(1, &texture);	// Free the texture.
	if (frame)
		frame->glshape = 0;	// Tell owner.
	}

/*
 *	Paint flat shapes
 */

void GL_texshape::paint
	(
	int px, int py,			// Location in 'pixels' from top-left
					//   of screen.
	Map_chunk *chunk = NULL,	//The chunk being rendered
	bool flat = true		//Should this shape be rendered as 2D?				
	)
	{
		if( flat )
	{
		if( !GL_manager::get_instance() || !frame )
			return;
		return GL_manager::get_instance()->paint_shape( frame, px, py );
	}
	float x = static_cast<float>(px);
	float y = static_cast<float>(py) + texsize;
	if (frame)
		{
		x += frame->get_xright() + 1 - (int) texsize;
		y += frame->get_ybelow() + 1 - (int) texsize;
		}
					// Game y-coord goes down from top.
	y = -y;
	float w = static_cast<float>(texsize), 
	      h = static_cast<float>(texsize);

	//Get into a perspective matrix
	GL_manager::get_instance()->use_matrix_persp();
	//Chunk translation
	glTranslatef( x, y, 0 );

	//Set up lighting
	float LightDir[]= { -0.577f, 0.577f, 0.577f, 0.0f };
	glLightfv( GL_LIGHT0, GL_POSITION, LightDir );

	//Paint flat scenery
		{
		//Draw floor of this chunk
		glDepthMask(GL_FALSE);
		glBindTexture(GL_TEXTURE_2D, texture);
		//During GL picking, we want to ignore the ground...
		glLoadName((unsigned int)NULL);
		glBegin(GL_QUADS);
			glColor4f(1,1,1,1);
			glNormal3f(0,0,1);
			glTexCoord2f(0, 0); glVertex3f(0, h, 0);
			glTexCoord2f(0, 1); glVertex3f(0, 0, 0);
			glTexCoord2f(1, 1); glVertex3f(w, 0, 0);
			glTexCoord2f(1, 0); glVertex3f(w, h, 0);
		glEnd();
		glDepthMask(GL_TRUE);
		}
	//Draw chunk objects
	if( chunk )
		{
		//Compensate for a rendering-order hack :-)
		glTranslatef( 0, texsize, 0 );
		//Get objects in this chunk
		Object_list &objects = chunk->get_objects();
		//Don't even bother?
		if( objects.is_empty() )
			return;
		//Which objects should we render?
		Main_actor *avatar = Game_window::get_instance()->get_main_actor();
		int roof = avatar->get_chunk()->is_roof( avatar->get_tx(), avatar->get_ty(), avatar->get_lift() );
		//Go through all the objects in the chunk!
        	Game_object *obj;
		Game_window *gwin = Game_window::get_instance();
	        Object_iterator next(objects);
	        while ((obj = next.get_next()) != NULL)
		        {
			//Don't draw eggs...
			if( !obj->is_findable() && !gwin->paint_eggs )
				continue;
			//Don't draw this object if it is too high...
			if( obj->get_lift() >= roof )
				continue;
			//Advance the animation a frame (virtual on Game_object)
			obj->start_animation();

			//Prepare to draw this object's textures...
			Shape_info &info = obj->get_info();
			Shape_frame *frame = obj->get_shape();
			GL_texshape *tex = frame->glshape;

			//Draw this object...
			glPushMatrix();
			//Store the object pointer for use in selection. This does nothing in normal rendering
			glLoadName( (unsigned int)obj );
			//Translate to the correct position to draw either a model or general case
			glTranslatef( obj->get_tx() * 8, obj->get_ty() * -8, obj->get_lift()*8 );
			glTranslatef( -info.get_dims(0)*8+8, -8, 0 );

			//Before drawing a general case, try to draw a 3D model. If we can, we can continue to the next iteration
			if( frame->model && frame->model->Render() )
			{
				glPopMatrix();
				continue;
			}

		        if (!tex)                       // Need to create texture?
				frame->glshape = tex = new GL_texshape(frame, GL_manager::get_instance()->palette, &Shape_manager::get_instance()->get_xform(0), 12);
		        glBindTexture( GL_TEXTURE_2D, frame->glshape->texture );

			/*
			 *
			 *            (0,0)               (bx,0)
			 *            x-------------------x
			 *            |                   |\
			 *            |                   | \
			 *            |                   |  \
			 *            |                   |   \
			 *            |        TOP        |    \
			 *            |                   |  E  \
			 *            |                   |  A   x -(tx,of)
			 *            |                   |  S   |
			 *            |                   |  T   |
			 *    (0,by)- x-------------------x- - - - -(bx,by)
			 *             \                   \     |
			 *              \                   \    |
			 *               \                   \   |
			 *                \       SOUTH       \  |
			 *                 \                   \ |
			 *                  \                   \|
			 *                   x-------------------x
			 *                   (of,ty)             (tx,ty)
			 * Textures are packed into square powers-of-2 textures
			 * For instance, a 37x55 texture would go into a
			 * 64x64 texture. Disregarding this information should
			 * still produce proper texture coordinates on the range
			 * of 0.0 to 1.0. 37 / 64 is 0.57, for instance, which 
			 * correctly represents the lost space to the bottom and
			 * right of the GL texture.
			 *
			 */

			const float
				//Offset epsilon value which we use to get just a little closer to texture center
				ep = 0.03f;

			float	// Figure bottom-right (of the top plane) texture coords
				bx = (float)info.get_dims(0)*8.0f / (float)tex->texsize,
				by = (float)info.get_dims(1)*8.0f / (float)tex->texsize,
				// Figure total bottom-right (of the whole frame) texture coorsd
				tx = (float)frame->get_width() / (float)tex->texsize,
				ty = (float)frame->get_height() / (float)tex->texsize,
				// Diagonal offset in the perspective
				of = (float)(frame->get_width()-info.get_dims(0)*8.0f) / (float)tex->texsize;

			bx -= ep;
			by -= ep;
			tx -= ep;
			ty -= ep;


			glBegin( GL_QUADS );
				//Top
				glNormal3f(0,0,1);
				glTexCoord2f(ep,ep); glVertex3f( 0, 			info.get_dims(1)*8, 	info.get_dims(2)*8 );
				glTexCoord2f(ep,by); glVertex3f( 0,			0,		 	info.get_dims(2)*8 );
				glTexCoord2f(bx,by); glVertex3f( info.get_dims(0)*8,	0, 			info.get_dims(2)*8 );
				glTexCoord2f(bx,ep); glVertex3f( info.get_dims(0)*8,	info.get_dims(1)*8, 	info.get_dims(2)*8 );
				//South
				glNormal3f(0,-1,0);
				glTexCoord2f(tx,ty); glVertex3f( info.get_dims(0)*8,	0,			0 );
				glTexCoord2f(bx,by); glVertex3f( info.get_dims(0)*8,	0, 			info.get_dims(2)*8 );
				glTexCoord2f(ep,by); glVertex3f( 0,			0,	 		info.get_dims(2)*8 );
				glTexCoord2f(of,ty); glVertex3f( 0, 			0,		 	0 );
				//East
				glNormal3f(1,0,0);
				glTexCoord2f(bx,ep); glVertex3f( info.get_dims(0)*8,	info.get_dims(1)*8, 	info.get_dims(2)*8 );
				glTexCoord2f(bx,by); glVertex3f( info.get_dims(0)*8,	0, 		     	info.get_dims(2)*8 );
				glTexCoord2f(tx,ty); glVertex3f( info.get_dims(0)*8,	0,		     	0 );
				glTexCoord2f(tx,of); glVertex3f( info.get_dims(0)*8,	info.get_dims(1)*8, 	0 );
				//West
				glNormal3f(-1,0,0);
				glTexCoord2f(tx,of); glVertex3f( 0, 			info.get_dims(1)*8,	0 );
				glTexCoord2f(tx,ty); glVertex3f( 0,			0,			0 );
				glTexCoord2f(bx,by); glVertex3f( 0,			0, 			info.get_dims(2)*8 );
				glTexCoord2f(bx,ep); glVertex3f( 0,			info.get_dims(1)*8, 	info.get_dims(2)*8 );
				//North
				glNormal3f(0,1,0);
				glTexCoord2f(of,ty); glVertex3f( 0, 			info.get_dims(1)*8, 	0 );
				glTexCoord2f(ep,by); glVertex3f( 0,			info.get_dims(1)*8,	info.get_dims(2)*8 );
				glTexCoord2f(bx,by); glVertex3f( info.get_dims(0)*8,	info.get_dims(1)*8,	info.get_dims(2)*8 );
				glTexCoord2f(tx,ty); glVertex3f( info.get_dims(0)*8,	info.get_dims(1)*8, 	0 );
/*
				//Bottom (upside down)
				glTexCoord2f(0,1); glVertex3f( 0, 				(info.get_dims(1)-0)*8,	 	0 );
				glTexCoord2f(0,0); glVertex3f( 0,				0,		 		0 );
				glTexCoord2f(1,0); glVertex3f( (info.get_dims(0)-0)*8,		0, 				0 );
				glTexCoord2f(1,1); glVertex3f( (info.get_dims(0)-0)*8,		(info.get_dims(1)-0)*8,	 	0 );
//*/
//*
				//Bottom
				glNormal3f(0,0,-1);
				glTexCoord2f(bx,ep); glVertex3f( info.get_dims(0)*8,	info.get_dims(1)*8, 	0 );
				glTexCoord2f(bx,by); glVertex3f( info.get_dims(0)*8,	0, 			0 );
				glTexCoord2f(ep,by); glVertex3f( 0,			0,		 	0 );
				glTexCoord2f(ep,ep); glVertex3f( 0, 			info.get_dims(1)*8, 	0 );

				glNormal3f(1,1,1); //Make everything else full-bright (quick hack) 
//*/
			glEnd();
			glPopMatrix();
	        	}
		}
	}

/*
 *	Create OpenGL manager.
 */

GL_manager::GL_manager
	(
	) : shapes(0), num_shapes(0), scale(1)
	{
	assert (instance == 0);		// Should only be one.
	instance = this;
	GLint max_size;
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &max_size);
	max_texsize = max_size;
//Set up the default GL rendering states
	glEnable( GL_CULL_FACE );
	glClearColor( 0.0, 0.0, 0.0, 0.0 );
	glClearDepth( 1 );
	//Set up vertex arrays for models
	glEnableClientState( GL_VERTEX_ARRAY );
	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	glEnableClientState( GL_NORMAL_ARRAY );
	//Alpha
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//Alpha testing
	glAlphaFunc( GL_GEQUAL, 0.01f );
	glEnable(GL_ALPHA_TEST);
	//Set up camera
	camera_pos = Vector3( 160, -120, 240 );
	camera_arc = Vector3( 0, 0, 0 );
	//Set up lighting
	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	glShadeModel( GL_SMOOTH );
	//Set up initial lighting
	glEnable( GL_NORMALIZE );
	float LightAmbient[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	float LightDiffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	float LightDir[]= { 0.577f, 0.577f, -0.577f, 0.0f };
	glLightfv( GL_LIGHT0, GL_AMBIENT, LightAmbient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, LightDiffuse );
	glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
	glLightfv( GL_LIGHT0, GL_POSITION, LightDir );
	glPopMatrix();
	glEnable( GL_LIGHT0 );
	//glEnable( GL_LIGHTING );

	printf("%s:%d - glGetError()=0x%08x\n",__FILE__,__LINE__,glGetError()); fflush(stdout);
	}

/*
 *	Free resources.
 */

GL_manager::~GL_manager
	(
	)
	{
	assert (this == instance);
	while (shapes)
		{
		GL_texshape *next = shapes->lru_next;
		delete shapes;
		shapes = next;
		}
	instance = 0;
	}
	
/*	
*	Move the camera "forward-backward", "left-right", and "up-down", relatively, and respecitvely
 */
void GL_manager::pan_camera( Vector3 dir )
	{
puts("panning");
	const float *m = matrix_persp;
	//Left/Right
	camera_pos += Vector3( m[0], m[4], m[8] ) * dir.x;
	//Forward/Backward
	camera_pos += Vector3( m[2], m[6], m[10] ) * dir.y;
	//Up/down
	camera_pos -= Vector3( m[1], m[5], m[9] ) * dir.z;
	}

/*
 *	Arc the camera horizontally and vertically, relatively and respectively.
 */
void GL_manager::arc_camera( Vector3 dir )
	{
puts("arcing:");
	camera_arc += dir / 360.0f;
	camera_arc.set_clamp( 1.0f );
	}

/*
 *	Set up the orthographic matrix and store a copy
 */

void GL_manager::set_matrix_ortho
	(
	)
	{
	//Modelview matrix (object to world space)
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//Set up the modelview matrix so that we clip from (0,0,0) to (320,240,0)
	glTranslatef( -160, 120, -240 );
	//Store a copy
	glGetFloatv( GL_MODELVIEW_MATRIX, matrix_ortho );
	}

/*
 *	Set up the perspective matrix and store a copy
 */

void GL_manager::set_matrix_persp
	(
	)
	{
	//Set up matrix according to our camera position and rotation
	//Determine Modelview matrix
        glMatrixMode( GL_MODELVIEW );
        glLoadIdentity();
        glRotatef( camera_arc[1] * 360.0, 1, 0, 0 );
        glRotatef( camera_arc[0] * 360.0, 0, 0, 1 );
        glTranslatef( -camera_pos.x, -camera_pos.y, -camera_pos.z );
	//Store a copy
	glGetFloatv( GL_MODELVIEW_MATRIX, matrix_persp );
	}

/*
 *	Load up the stored perspective modelview matrix
 */

void GL_manager::use_matrix_persp
	(	
	)
	{
	//Modelview matrix (object to world space)
	glMatrixMode(GL_MODELVIEW);
	//Load stored copy
	glLoadMatrixf( matrix_persp );
	}

/*
 *	Load up the stored orthographic modelview matrix
 */

void GL_manager::use_matrix_ortho
	(	
	)
	{
	//Modelview matrix (object to world space)
	glMatrixMode(GL_MODELVIEW);
	//Load stored copy
	glLoadMatrixf( matrix_ortho );
	}


/*
 *	Window was resized.
 */
void GL_manager::resized
	(
	int new_width, int new_height,
	int new_scale
	)
	{
	scale = new_scale;
	//Viewport (full window)
	glViewport(0, 0, scale*new_width, scale*new_height);
	//Set up the projection matrix (world to screen space)
	glMatrixMode(GL_PROJECTION);	// Set up orthogonal volume.
	glLoadIdentity();
	//I don't want to pollute the code with GLUT just for gluPerspective, so let's just make our own version.
//	gluPerspective( 45.0, (float)new_width / (float)new_height, 0.1, 100.0f );
        double fW, fH;
        fH = tan( 45.0 / 180 * 3.1415926535897932384626433832795 ) * 0.1 / 2;
        fW = fH * ( (float)new_width / (float)new_height );
        glFrustum( -fW, fW, -fH, fH, 0.1, 1000.0 );
	//Store a copy
	glGetFloatv( GL_PROJECTION_MATRIX, matrix_proj );
	//Set up initial modelview matrices
	set_matrix_ortho();
	set_matrix_persp();
	glGetIntegerv(GL_VIEWPORT, viewport);
	//Rendering states
#if 0
	glDisable(GL_TEXTURE_2D);
	glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
#else
	glEnable(GL_TEXTURE_2D);
#endif
	glEnable(GL_DEPTH_TEST);
	printf( "Created an OpenGL rendering context\n" );
	}

/*
 *	Figure offsets on screen.
 */

inline int Figure_screen_offset
        (
        int ch,                         // Chunk #
        int scroll                      // Top/left tile of screen.
        )
        {
                                        // Watch for wrapping.
        int t = ch*c_tiles_per_chunk - scroll;
        if (t < -c_num_tiles/2)
                t += c_num_tiles;
        t %= c_num_tiles;
        return t*c_tilesize;
        }

/*
 *	Construct a 2D shape (should not be put into perspective) and paint it
 */

void GL_manager::paint_shape
	(
	Shape_frame *frame,
	int offx,			// Position in pixels from top-left of a 320x200 screen
	int offy			// 
	)
	{
	GL_texshape *tex = frame->glshape;
	if (!tex)		       // Need to create texture?
		{
		if (frame->get_width() > max_texsize ||
		    frame->get_height() > max_texsize)
			{	       // Too big?  Just paint it now.
			puts("Debug::Failed on a GL texture because it's too big");
			return;
			}
		//frame->glshape = tex = new GL_texshape(frame, palette);
		frame->glshape = tex = new GL_texshape(frame, GL_manager::get_instance()->palette, &Shape_manager::get_instance()->get_xform(0), 12);
		num_shapes++;
//printf("GL_manager::paint_shape(0x%08x,%d,%d) - created texture\n",frame,offx,offy);
		//++++++When 'too many', we'll free LRU here.
		}
		
	int w, h;
	w = h  = tex->texsize;

        float x = static_cast<float>(offx) - frame->get_xleft();
        float y = static_cast<float>(offy) + h - frame->get_yabove();
        if (frame)
                {
                //x += frame->get_xright();// + 1 - w;
                //y -= frame->get_ybelow();// + 1 - h;
                }
                                        // Game y-coord goes down from top.
        y = -y;

	use_matrix_ortho();

	glTranslatef( x, y, 0 );
	glBindTexture(GL_TEXTURE_2D, tex->texture);
	glDisable(GL_DEPTH_TEST);

	glColor4f(1,1,1,1);

	glBegin(GL_QUADS);
		glColor4f(1,1,1,1);
		glTexCoord2f(0, 0); glVertex3f(0, h, 0);
		glTexCoord2f(0, 1); glVertex3f(0, 0, 0);
		glTexCoord2f(1, 1); glVertex3f(w, 0, 0);
		glTexCoord2f(1, 0); glVertex3f(w, h, 0);
	glEnd();

	glEnable(GL_DEPTH_TEST);


//	paint( frame, offx, offy );
	}

/*
 *	Paint a shape.
 */

void GL_manager::paint
	(
	Shape_frame *frame,
	int px, int py,			// 'Pixel' position from top-left.
	Xform_palette *xforms,		// Transforms translucent colors if !0.
	int xfcnt			// Number of xforms.
	)
	{
	GL_texshape *tex = frame->glshape;
	if (!tex)			// Need to create texture?
		{
		if (frame->get_width() > max_texsize || 
		    frame->get_height() > max_texsize)
			{		// Too big?  Just paint it now.
			puts("Debug::Failed on a GL texture because it's too big");
			return;
			}
		frame->glshape = tex = new GL_texshape(frame, GL_manager::get_instance()->palette, &Shape_manager::get_instance()->get_xform(0), 12);
//		frame->glshape = tex = new GL_texshape(frame, palette, xforms, xfcnt);
		num_shapes++;
		//++++++When 'too many', we'll free LRU here.
		}
	else				// Remove from chain.
		{
		if (tex->lru_next)
			tex->lru_next->lru_prev = tex->lru_prev;
		if (tex->lru_prev)
			tex->lru_prev->lru_next = tex->lru_next;
		tex->lru_prev = 0;	// It will go to the head.
		}
	tex->lru_next = shapes;		// Add to head of chain.
	if (shapes)
		shapes->lru_prev = tex;
	shapes = tex;
	tex->paint(px, py);
	}

#endif	/* HAVE_OPENGL */
